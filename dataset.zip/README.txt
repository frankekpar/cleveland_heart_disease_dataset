OVERVIEW

This dataset is derived from the Cleveland Heart Disease dataset publicly available from the University of California Irvine 
Machine Learning Repository at https://archive.ics.uci.edu/.
Incomplete entries have been removed from the dataset.


DATA STRUCTURE

The dataset comprises rows of numbers in comma separated values (CSV) format.
There are fourteen (14) columns in each row of data.
Each row represents clinical measurements (the first 13 columns) from a distinct participant and a number in the last or 
fourteenth column (0, 1, 2, 3 or 4) indicating the presence (1, 2, or 3) or absence (0) of heart disease in the selected 
participant.

The clinical measurements indicated in the first 13 columns of each row are (in order of appearance):

1. Age (in years)
2. Sex (Male or Female)
3. Resting blood pressure 
4. Serum cholesterol
5. Fasting blood sugar
6. Resting electrocardiographic (ECG) results
7. Maximum heart rate
8. Exercise-induced angina presence
9. ST depression induced by exercise relative to rest
10. Slope of peak exercise ST segment
11. Number of major vessels (0 - 3) 
12. Colored by fluoroscopy
13. Heart performance
